package drexel.edu.se310.constants;

public enum Type {

  SURVEY, TEST;
}
