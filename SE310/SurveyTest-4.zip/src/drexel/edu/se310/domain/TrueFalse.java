package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class TrueFalse extends MultipleChoice {

  public TrueFalse() {
    super();
    setDefaultChoices();
  }

  public TrueFalse(String questionPrompt) {
    super(questionPrompt);
    setDefaultChoices();
  }

  private void setDefaultChoices() {
    Map<String, String> choices = this.getChoices();
    choices.put("T", SurveyTestConstants.TRUE);
    choices.put("F", SurveyTestConstants.FALSE);
  }

  @Override
  public String getChoiceValue(String key) {
    return this.getChoices().get(key);
  }

  @Override
  public ResponseCorrectAnswer buildQuestion(Scanner scan, Type type, int index) {
    System.out.println(SurveyTestConstants.TORF);
    this.setQuestionType(type);
    String option = scan.nextLine();
    this.setQuestionPrompt(option.concat("?"));
    this.setQuestionNumber(index);
    return (getCorrectAnswers(scan));
  }

  @Override
  public List<String> getCorrectAnswer(ResponseCorrectAnswer correctAnswer, String option) {
    List<String> resp = correctAnswer.getResponse();
    String s = this.getChoices().get(option.toUpperCase());
    resp.add(s.equalsIgnoreCase(SurveyTestConstants.TRUE) ? SurveyTestConstants.TRUE : SurveyTestConstants.FALSE);
    return resp;
  }

  @Override
  public boolean checkAnswerInChoices(String option, String answer, int numAnswers) {
    if (option.isEmpty()) {
      return false;
    }
    for (Map.Entry<String, String> s : getChoices().entrySet()) {
      if (s.getKey().equalsIgnoreCase(option)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public ResponseCorrectAnswer getCorrectAnswers(Scanner scan) {
    if (this.getQuestionType().equals(Type.SURVEY)) {
      return null;
    }
    ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
    String answer = "[T/F]";
    String option = "";
    while (!checkAnswerInChoices(option, "", 0)) {
      System.out.println(SurveyTestConstants.CORRECT_CHOICE + answer);
      option = scan.nextLine();
    }
    correctAnswer.setResponse(getCorrectAnswer(correctAnswer, option));
    return correctAnswer;
  }

  @Override
  public void displayQuestion(Type type) {
    System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
    StringBuffer sb = new StringBuffer();
    for (Map.Entry<String, String> s : this.getChoices().entrySet()) {
      sb.append(s.getValue() + "/");
    }
    sb.deleteCharAt(sb.length() - 1);
    System.out.println(sb.toString());
  }

  @Override
  public void modifyQuestion(Scanner scan) {
    System.out.println("Do you wish to modify the prompt?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("Current prompt is: " + this.getQuestionPrompt());
      System.out.println("Enter a new prompt:");
      String newPrompt = scan.nextLine();
      newPrompt = newPrompt.trim();
      this.setQuestionPrompt(newPrompt);
    }
  }

  @Override
  public void answerQuestion(Object rc, Scanner scan) {
    String option = SurveyTestUtil.getMenuOptionForTrueOrFalse();
    ResponseCorrectAnswer userAnswer = new ResponseCorrectAnswer();
    List<String> al = new ArrayList<>();
    al.add(option);
    userAnswer.setResponse(al);
    this.setUserAnswer(userAnswer);
  }

  @Override
  public void printTabulation(String i, int index, List<Map<String, Integer>> lm) {
    System.out.println(this.getChoices().get(i) + ": " + lm.get(index).get(i).toString().toUpperCase());
  }
}
