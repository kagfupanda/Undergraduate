package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.Type;

public abstract class Question {

  private String questionPrompt;
  private ResponseCorrectAnswer userAnswer;
  private HashMap<Integer, String> userMatchChoiceAnswer;
  private int questionNumber = 0;
  private Type questionType;

  public Question() {

  }

  public HashMap<Integer, String> getUserMatchChoiceAnswer() {
    return this.userMatchChoiceAnswer;
  }

  public void setUserMatchChoiceAnswer(HashMap<Integer, String> userMatchChoiceAnswer) {
    this.userMatchChoiceAnswer = userMatchChoiceAnswer;
  }

  public Type getQuestionType() {
    return this.questionType;
  }

  public void setQuestionType(Type questionType) {
    this.questionType = questionType;
  }

  public Question(String questionPrompt) {
    super();
    this.questionPrompt = questionPrompt;
  }

  public ResponseCorrectAnswer getUserAnswer() {
    return this.userAnswer;
  }

  public void setUserAnswer(ResponseCorrectAnswer userAnswer) {
    this.userAnswer = userAnswer;
  }

  public String getQuestionPrompt() {
    return this.questionPrompt;
  }

  public int getQuestionNumber() {
    return this.questionNumber;
  }

  public void setQuestionNumber(int questionNumber) {
    this.questionNumber = questionNumber;
  }

  public void setQuestionPrompt(String questionPrompt) {
    this.questionPrompt = questionPrompt;
  }

  public String getCharForNumber(int i) {
    return i > 0 && i < 27 ? String.valueOf((char) (i + 64)) : null;
  }

  public List<String> getCorrectAnswer(ResponseCorrectAnswer correctAnswer, String option) {

    List<String> resp = correctAnswer.getResponse();
    option = option.replaceAll("\\s", "");
    for (String o : option.split(",")) {
      resp.add(o.toUpperCase());
    }
    return resp;
  }

  public boolean isNumeric(final String str) {
    if (str == null || str.length() == 0) {
      return false;
    }
    for (char c : str.toCharArray()) {
      if (!Character.isDigit(c)) {
        return false;
      }
    }
    return true;
  }

  protected boolean notMoreThanMax(String option) {
    if (option.isEmpty())
      return true;
    int numChoices = Integer.parseInt(option);
    if (numChoices <= 0)
      return true;
    return false;
  }

  public abstract Object buildQuestion(Scanner scan, Type type, int index);

  public abstract void displayQuestion(Type type);

  public abstract void modifyQuestion(Scanner scan);

  public abstract ResponseCorrectAnswer getCorrectAnswers(Scanner scan);

  public abstract HashMap<Integer, String> getCorrectMatchingAnswers(Scanner scan);

  public abstract void answerQuestion(Object rc, Scanner scan);

  public abstract void printTabulation(String i, int index, List<Map<String, Integer>> lm);

  public abstract void buildQuestionTabulation(List<Map<String, Integer>> lm, Map<String, Integer> tfCount,
      List<Map<Integer, String>> ml, Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex);

  public String getChoiceValue(String key) {
    return "";
  }

  public void printAllTabulation(List<Survey> surveyList, List<Map<String, Integer>> lm, List<Map<Integer, String>> ml,
      Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex, int rankingIndex) {
    int index = this.getQuestionNumber() - 1;

    System.out.println("Replies:");
    for (Survey sur : surveyList) {
      List<String> key = sur.getQuestions().get(index).getUserAnswer().getResponse();
      for (String s : key) {
        String sCaps = s.toString().toUpperCase();
        String value = sur.getQuestions().get(index).getChoiceValue(sCaps);
        if (value.isEmpty()) {
          System.out.println(s);
        } else {
          System.out.println(value);
        }
      }
    }
    System.out.println("\nTabulation: ");
    for (String i : lm.get(lmIndex).keySet()) {
      this.printTabulation(i, lmIndex, lm);
    }
    index++;
  }

  public void answerMatchingQuestion(HashMap<Integer, String> rc, Scanner scan) {
    // TODO Auto-generated method stub

  }

}
