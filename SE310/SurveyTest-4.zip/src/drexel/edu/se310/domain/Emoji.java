package drexel.edu.se310.domain;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class Emoji extends MultipleChoice {

  public Emoji() {
    super();
    setDefaultChoices();
  }

  public Emoji(String questionPrompt) {
    super(questionPrompt);
    setDefaultChoices();
  }

  private void setDefaultChoices() {
    Map<String, String> choices = this.getChoices();
    choices.put(getCharForNumber(1), SurveyTestConstants.SMILES);
    choices.put(getCharForNumber(2), SurveyTestConstants.FROWN);
    choices.put(getCharForNumber(3), SurveyTestConstants.ANGRY);
    choices.put(getCharForNumber(4), SurveyTestConstants.SURPRISED);
    choices.put(getCharForNumber(5), SurveyTestConstants.SAD);
  }

  @Override
  public ResponseCorrectAnswer buildQuestion(Scanner scan, Type type, int index) {
    System.out.println(SurveyTestConstants.EMOJI);
    this.setQuestionType(type);
    return (buildCommonQuestion(scan, type, index, false));
  }

  @Override
  public void modifyQuestion(Scanner scan) {
    System.out.println("Do you wish to modify the prompt?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("Current prompt is: " + this.getQuestionPrompt());
      System.out.println("Enter a new prompt:");
      String newPrompt = scan.nextLine();
      newPrompt = newPrompt.trim();
      this.setQuestionPrompt(newPrompt);
    }
  }

  @Override
  public void printTabulation(String i, int index, List<Map<String, Integer>> lm) {
    System.out.println(this.getChoices().get(i) + ": " + lm.get(index).get(i));
  }
}
