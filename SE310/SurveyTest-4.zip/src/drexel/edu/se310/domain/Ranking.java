package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class Ranking extends MultipleChoice {

  @Override
  public ResponseCorrectAnswer buildQuestion(Scanner scan, Type type, int index) {
    System.out.println("Enter the prompt or your Ranking question:");
    this.setQuestionType(type);
    String prompt = "Enter the number of choices for your ranking question.";
    return (buildCommonQuestion(scan, type, index, true, prompt));
  }

  @Override
  public ResponseCorrectAnswer getCorrectAnswers(Scanner scan) {
    ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
    String answer = getAnswerChoicesForMCQ();
    if (this.getQuestionType().equals(Type.SURVEY)) {
      return null;
    }
    String option = "";
    while (!checkAnswerInChoices(option, answer, 0)) {
      System.out.println(SurveyTestConstants.RANKING_MULTI_ANSWER + answer);
      option = scan.nextLine();
    }
    correctAnswer.setResponse(getCorrectAnswer(correctAnswer, option));
    return correctAnswer;
  }

  @Override
  protected void getUserAnswers(Scanner scan, int numAnswers) {
    ResponseCorrectAnswer userAnswer = new ResponseCorrectAnswer();
    String answer = getAnswerChoicesForMCQ();
    String option = "";
    while (!checkAnswerInChoices(option, answer, 0)) {
      System.out.println(SurveyTestConstants.RANKING_MULTI_ANSWER + answer);
      option = scan.nextLine();
    }
    String[] ansList = option.split(",");
    for (int i = 0; i < ansList.length; i++) {
      ansList[i] = ansList[i].replaceAll("\\s", "").toUpperCase();
    }
    List<String> al = new ArrayList<>();
    al.addAll(Arrays.asList(ansList));
    al.replaceAll(String::toUpperCase);
    userAnswer.setResponse(al);
    this.setUserAnswer(userAnswer);
  }

  @Override
  public boolean checkAnswerInChoices(String option, String answer, int numAnswers) {
    if (option.isEmpty()) {
      return false;
    }
    answer = answer.replaceAll("\\[", "");
    answer = answer.replaceAll("\\]", "");
    option = option.replaceAll("\\s", "");
    String[] s1 = answer.split(",");
    String[] s2 = option.split(",");
    List<String> s1List = Arrays.asList(s1);
    List<String> s2List = Arrays.asList(s2);
    s2List.replaceAll(String::toUpperCase);
    Collections.sort(s1List);
    Collections.sort(s2List);
    if (s1List.equals(s2List)) {
      return true;
    }
    return false;
  }

  @Override
  public void answerQuestion(Object rc, Scanner scan) {
    getUserAnswers(scan, 0);
    System.out.println();
  }

  @Override
  public void buildQuestionTabulation(List<Map<String, Integer>> lm, Map<String, Integer> tfCount,
      List<Map<Integer, String>> ml, Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex) {
    List<String> ans = this.getUserAnswer().getResponse();
    List<ArrayList<String>> sl = null;
    sl = rankingTabList.get(this.getQuestionNumber() - 1);
    if (sl == null) {
      sl = new ArrayList<>();
    }
    sl.add((ArrayList<String>) ans);
    rankingTabList.put(this.getQuestionNumber() - 1, sl);
  }

  @Override
  public void printAllTabulation(List<Survey> surveyList, List<Map<String, Integer>> lm, List<Map<Integer, String>> ml,
      Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex, int rankingIndex) {
    int index = this.getQuestionNumber() - 1;

    System.out.println("Replies:");
    for (Survey sur : surveyList) {
      List<String> key = sur.getQuestions().get(index).getUserAnswer().getResponse();
      for (String s : key) {
        String sCaps = s.toString().toUpperCase();
        String value = sur.getQuestions().get(index).getChoiceValue(sCaps);
        if (value.isEmpty()) {
          System.out.println(s);
        } else {
          System.out.println(value);
        }
      }
      System.out.println();
    }
    System.out.println("\nTabulation:");
    // process the unique list and its count
    Map<ArrayList<String>, Integer> sl = new HashMap<>();
    List<ArrayList<String>> rank = rankingTabList.get(index);
    for (ArrayList<String> r : rank) {
      sl.put(r, Collections.frequency(rank, r));
    }

    for (Map.Entry<ArrayList<String>, Integer> entry : sl.entrySet()) {
      System.out.println(entry.getValue());
      entry.getKey().forEach(System.out::println);
      System.out.println();
    }
  }

}
