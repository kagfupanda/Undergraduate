package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class ShortAnswer extends Essay {

  public ShortAnswer() {
    super();
  }

  public ShortAnswer(String questionPrompt) {
    super(questionPrompt);
  }

  @Override
  public ResponseCorrectAnswer buildQuestion(Scanner scan, Type type, int index) {
    this.setQuestionType(type);
    System.out.println(SurveyTestConstants.SHORTANSWER);
    String option = scan.nextLine();
    this.setQuestionNumber(index);
    this.setQuestionPrompt(option.concat("?"));
    return (getCorrectAnswers(scan));
  }

  @Override
  public void displayQuestion(Type type) {
    System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
  }

  @Override
  public void modifyQuestion(Scanner scan) {
    System.out.println("Do you wish to modify the short answer prompt?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("Current short answer prompt is: " + this.getQuestionPrompt());
      System.out.println("Enter a new short answer prompt:");
      String newPrompt = scan.nextLine();
      newPrompt = newPrompt.trim();
      this.setQuestionPrompt(newPrompt);
    }
  }

  @Override
  public void printTabulation(String i, int index, List<Map<String, Integer>> lm) {
    System.out.println(i + ": " + lm.get(index).get(i));
  }

  @Override
  public void buildQuestionTabulation(List<Map<String, Integer>> lm, Map<String, Integer> tfCount,
      List<Map<Integer, String>> ml, Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex) {
    List<String> ans = this.getUserAnswer().getResponse();
    for (String a : ans)
      SurveyTestUtil.incrementValueWithSameCaseForShortAnswers(tfCount, a);
    lm.add(tfCount);
  }
}
