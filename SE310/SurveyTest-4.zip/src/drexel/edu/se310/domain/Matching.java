package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class Matching extends Question {

  private MatchChoice matchChoice = new MatchChoice();
  private int numChoices = 0;

  public Matching() {
    super();
  }

  public int getNumChoices() {
    return this.numChoices;
  }

  public void setNumChoices(int numChoices) {
    this.numChoices = numChoices;
  }

  public Matching(String questionPrompt) {
    super(questionPrompt);
  }

  public MatchChoice getMatchChoice() {
    return this.matchChoice;
  }

  public void setMatchChoice(MatchChoice matchChoice) {
    this.matchChoice = matchChoice;
  }

  @Override
  public HashMap<Integer, String> buildQuestion(Scanner scan, Type type, int index) {
    this.setQuestionType(type);
    System.out.println("Enter the question:");
    String option = scan.nextLine();
    this.setQuestionPrompt(option.concat("?"));
    this.setQuestionNumber(index);
    option = "";
    while (!isNumeric(option) || notMoreThanMax(option)) {
      System.out.println(SurveyTestConstants.MCQ_CHOICES);
      option = scan.nextLine();
    }
    this.numChoices = Integer.parseInt(option);
    for (int i = 1; i <= this.numChoices; i++) {
      System.out.println("Column A: Enter choice #" + i);
      option = scan.nextLine();
      this.matchChoice.getColumnA().put(i - 1, option);
      System.out.println("Column B: Enter choice #" + i);
      option = scan.nextLine();
      this.matchChoice.getColumnB().put(i - 1, option);
    }
    return getCorrectMatchingAnswers(scan);
  }

  private boolean columnBIsMore(int numChoices, String str) {
    if (isNumeric(str)) {
      int k = Integer.parseInt(str);
      if (k > numChoices || k <= 0) {
        return true;
      }
    }
    return false;
  }

  @Override
  public void displayQuestion(Type type) {
    System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
    StringBuffer sb = new StringBuffer();
    SurveyTestUtil.printBorder();
    System.out.println("COLUMN A\t COLUMN B");
    SurveyTestUtil.printBorder();
    for (int i = 0; i < this.matchChoice.getColumnA().size(); i++) {
      sb.append(i + 1 + ")" + this.matchChoice.getColumnA().get(i));
      sb.append("\t");
      sb.append(i + 1 + ")" + this.matchChoice.getColumnB().get(i));
      System.out.println(sb.toString());
      sb.delete(0, sb.length());
    }
  }

  @Override
  public void modifyQuestion(Scanner scan) {
    System.out.println("Do you wish to modify the prompt?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("Current prompt is: " + this.getQuestionPrompt());
      System.out.println("Enter a new prompt:");
      String newPrompt = scan.nextLine();
      newPrompt = newPrompt.trim();
      this.setQuestionPrompt(newPrompt);
    }
    System.out.println("Do you wish to modify choices?");
    if (SurveyTestUtil.getYesNoAnswer()) {
      System.out.println("Which choice would you like to modify?");
      displayQuestion(Type.SURVEY);
      System.out.println("Enter choice: ");
      String ans = SurveyTestUtil.getMenuOption(true, this.getMatchChoice().getColumnA().size());
      System.out.println("Which column would you like to modify:");
      ans = SurveyTestUtil.getMenuStringOption(true, 2);
      System.out.println("Enter new value for column " + ans.toUpperCase());
      String newValue = scan.nextLine();
      newValue = newValue.trim();
      int at = ans.toUpperCase().charAt(0) - 65;
      if (ans.equalsIgnoreCase("a")) {
        this.getMatchChoice().getColumnA().put(at, newValue);
      } else {
        this.getMatchChoice().getColumnB().put(at, newValue);
      }
    }
  }

  @Override
  public HashMap<Integer, String> getCorrectMatchingAnswers(Scanner scan) {
    if (this.getQuestionType().equals(Type.SURVEY)) {
      return null;
    }
    HashMap<Integer, String> matchAnswers = new HashMap<>();
    for (int i = 1; i <= this.numChoices; i++) {
      String[] parsedOption = null;
      while (parsedOption == null || parsedOption.length != 2 || !isNumeric(parsedOption[0])
          || !isNumeric(parsedOption[1]) || (isNumeric(parsedOption[0]) && Integer.parseInt(parsedOption[0]) != i)
          || columnBIsMore(this.numChoices, parsedOption[1])) {
        System.out.println("Enter space separated correct choice for question #" + i + " [Ex: " + i + " 2]:");
        String option = scan.nextLine();
        parsedOption = option.split(" ");
      }
      matchAnswers.put(Integer.parseInt(parsedOption[0]), parsedOption[1]);
    }
    return matchAnswers;
  }

  @Override
  public ResponseCorrectAnswer getCorrectAnswers(Scanner scan) {
    return null;
  }

  @Override
  public void answerQuestion(Object rc, Scanner scan) {
    Map<Integer, HashMap<Integer, String>> resp = (Map<Integer, HashMap<Integer, String>>) rc;
    this.numChoices = resp == null ? this.numChoices : resp.size();
    HashMap<Integer, String> ma = getUserMatchingAnswers(scan);
    this.setUserMatchChoiceAnswer(ma);
    System.out.println();
  }

  private HashMap<Integer, String> getUserMatchingAnswers(Scanner scan) {
    HashMap<Integer, String> matchAnswers = new HashMap<>();
    for (int i = 1; i <= this.numChoices; i++) {
      String[] parsedOption = null;
      while (parsedOption == null || parsedOption.length != 2 || !isNumeric(parsedOption[0])
          || !isNumeric(parsedOption[1]) || (isNumeric(parsedOption[0]) && Integer.parseInt(parsedOption[0]) != i)
          || columnBIsMore(this.numChoices, parsedOption[1])) {
        System.out.println("Enter space separated answer for question #" + i + " [Ex: " + i + " 2]:");
        String option = scan.nextLine();
        parsedOption = option.split(" ");
      }
      matchAnswers.put(Integer.parseInt(parsedOption[0]), parsedOption[1]);
    }
    return matchAnswers;
  }

  @Override
  public void printTabulation(String i, int index, List<Map<String, Integer>> lm) {
  }

  @Override
  public void buildQuestionTabulation(List<Map<String, Integer>> lm, Map<String, Integer> tfCount,
      List<Map<Integer, String>> ml, Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex) {
    Map<Integer, String> mu = this.getUserMatchChoiceAnswer();
    ml.add(mu);
  }

  @Override
  public void printAllTabulation(List<Survey> surveyList, List<Map<String, Integer>> lm, List<Map<Integer, String>> ml,
      Map<Integer, List<ArrayList<String>>> rankingTabList, int lmIndex, int rankingIndex) {
    System.out.println("Replies: ");

    int qNum = this.getQuestionNumber() - 1;
    for (Survey sur : surveyList) {
      Question q = sur.getQuestions().get(qNum);
      for (Integer k : q.getUserMatchChoiceAnswer().keySet()) {
        System.out.println(k + " " + q.getUserMatchChoiceAnswer().get(k));
      }
      System.out.println();
    }
    Map<Map<Integer, String>, Integer> hm = new HashMap<>();
    // Temporary list to build unique values
    List<Map<Integer, String>> newList = new ArrayList<>();
    for (Map<Integer, String> i : ml) {
      if (!newList.contains(i)) {
        newList.add(i);
        SurveyTestUtil.incrementValueMapOfMap(hm, i);
      } else {
        Integer p = hm.get(i);
        hm.put(i, p + 1);
      }
    }
    System.out.println("Tabulation: ");
    for (Map<Integer, String> i : hm.keySet()) {
      System.out.println(hm.get(i));
      for (Integer k : i.keySet()) {
        System.out.println(k + " " + i.get(k));
      }
      System.out.println();
    }
  }
}
