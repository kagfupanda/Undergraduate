package drexel.edu.se310.domain;

import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class Emoji extends MultipleChoice {

	public Emoji() {
		super();
		setDefaultChoices();
	}

	public Emoji(String questionPrompt) {
		super(questionPrompt);
		setDefaultChoices();
	}

	private void setDefaultChoices() {
		Map<String, String> choices = this.getChoices();
		choices.put(getCharForNumber(1), SurveyTestConstants.SMILES);
		choices.put(getCharForNumber(2), SurveyTestConstants.FROWN);
		choices.put(getCharForNumber(3), SurveyTestConstants.ANGRY);
		choices.put(getCharForNumber(4), SurveyTestConstants.SURPRISED);
		choices.put(getCharForNumber(5), SurveyTestConstants.SAD);
	}

	@Override
	public void buildQuestion(Scanner scan, Type type, Test test, int index) {
		System.out.println(SurveyTestConstants.EMOJI);
		buildCommonQuestion(scan, type, test, index, false);
	}

}
