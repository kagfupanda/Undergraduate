package drexel.edu.se310.domain;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class TrueFalse extends MultipleChoice {

	public TrueFalse() {
		super();
		setDefaultChoices();
	}

	public TrueFalse(String questionPrompt) {
		super(questionPrompt);
		setDefaultChoices();
	}

	private void setDefaultChoices() {
		Map<String, String> choices = this.getChoices();
		choices.put("T", SurveyTestConstants.TRUE);
		choices.put("F", SurveyTestConstants.FALSE);
	}

	@Override
	public void buildQuestion(Scanner scan, Type type, Test test, int index) {
		System.out.println(SurveyTestConstants.TORF);
		String option = scan.nextLine();
		this.setQuestionPrompt(option.concat("?"));
		this.setQuestionNumber(index);
		if (type.equals(Type.TEST)) {
			ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
			String answer = "[T/F]";
			option = "";
			while (!checkAnswerInChoices(option, "")) {
				System.out.println(SurveyTestConstants.CORRECT_CHOICE + answer);
				option = scan.nextLine();
			}
			correctAnswer.setResponse(getCorrectAnswer(correctAnswer, option));
			test.getCorrectAnswers().add(index - 1, correctAnswer);
		}
	}

	@Override
	public List<String> getCorrectAnswer(ResponseCorrectAnswer correctAnswer, String option) {
		List<String> resp = correctAnswer.getResponse();
		resp.add(option.equalsIgnoreCase(SurveyTestConstants.TRUE) ? SurveyTestConstants.TRUE : SurveyTestConstants.FALSE);
		return resp;
	}

	@Override
	public boolean checkAnswerInChoices(String option, String answer) {
		if (option.isEmpty()) {
			return false;
		}
		for (Map.Entry<String, String> s : getChoices().entrySet()) {
			if (s.getKey().equalsIgnoreCase(option)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void displayQuestion(Type type, Test test) {
		System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
		StringBuffer sb = new StringBuffer();
		for (Map.Entry<String, String> s : this.getChoices().entrySet()) {
			sb.append(s.getValue() + "/");
		}
		sb.deleteCharAt(sb.length() - 1);
		System.out.println(sb.toString());
		if (type.equals(Type.TEST)) {
			System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS
			    + test.getCorrectAnswers().get(this.getQuestionNumber() - 1).getResponse());
		}
		System.out.println();
	}
}
