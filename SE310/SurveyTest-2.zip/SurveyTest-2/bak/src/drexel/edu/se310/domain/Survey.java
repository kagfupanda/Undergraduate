package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.List;

public class Survey {

  private String name;
  private List<Question> questions = new ArrayList<>();

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<Question> getQuestions() {
    return this.questions;
  }

  public void setQuestions(List<Question> questions) {
    this.questions = questions;
  }
}
