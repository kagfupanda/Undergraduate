package drexel.edu.se310.domain;

import java.util.List;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class ShortAnswer extends Essay {

	public ShortAnswer() {
		super();
	}

	public ShortAnswer(String questionPrompt) {
		super(questionPrompt);
	}

	@Override
	public void buildQuestion(Scanner scan, Type type, Test test, int index) {
		System.out.println(SurveyTestConstants.SHORTANSWER);
		String option = scan.nextLine();
		this.setQuestionNumber(index);
		this.setQuestionPrompt(option.concat("?"));
		if (type.equals(Type.TEST)) {
			System.out.println("Enter correct choice:");
			option = scan.nextLine();
			ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
			List<String> resp = correctAnswer.getResponse();
			resp.add(option);
			correctAnswer.setResponse(resp);
			test.getCorrectAnswers().add(index - 1, correctAnswer);
		}
	}

	@Override
	public void displayQuestion(Type type, Test test) {
		System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
		if (type.equals(Type.TEST)) {
			System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS
			    + test.getCorrectAnswers().get(this.getQuestionNumber() - 1).getResponse());
		}
		System.out.println();
	}
}
