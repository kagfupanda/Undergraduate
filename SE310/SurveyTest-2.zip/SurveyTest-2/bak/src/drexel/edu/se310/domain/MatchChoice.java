package drexel.edu.se310.domain;

import java.util.HashMap;
import java.util.Map;

public class MatchChoice {

  Map<Integer, String> columnA = new HashMap<>();
  Map<Integer, String> columnB = new HashMap<>();

  public Map<Integer, String> getColumnA() {
    return this.columnA;
  }

  public void setColumnA(Map<Integer, String> columnA) {
    this.columnA = columnA;
  }

  public Map<Integer, String> getColumnB() {
    return this.columnB;
  }

  public void setColumnB(Map<Integer, String> columnB) {
    this.columnB = columnB;
  }

}
