package drexel.edu.se310.domain;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class MultipleChoice extends Question {

	private Map<String, String> choices = new HashMap<>();

	public MultipleChoice() {
		super();
	}

	public MultipleChoice(String questionPrompt) {
		super(questionPrompt);
	}

	public Map<String, String> getChoices() {
		return this.choices;
	}

	public void setChoices(Map<String, String> choices) {
		this.choices = choices;
	}

	public void buildCommonQuestion(Scanner scan, Type type, Test test, int index, boolean askMCQ) {
		int numChoices = 0;
		String option = scan.nextLine();
		this.setQuestionPrompt(option.concat("?"));
		this.setQuestionNumber(index);
		option = ""; // reset
		if (askMCQ) {
			while (!isNumeric(option) || notMoreThanMax(option)) {
				System.out.println(SurveyTestConstants.MCQ_CHOICES);
				System.out.println("(max choices allowed is " + SurveyTestConstants.MAX_NUM_CHOICES + ")");
				option = scan.nextLine();
			}
			Map<String, String> pchoices = new HashMap<>();
			numChoices = Integer.parseInt(option);
			for (int i = 1; i <= numChoices; i++) {
				System.out.println("Enter choice #" + i);
				option = scan.nextLine();
				pchoices.put(getCharForNumber(i), option);
			}
			this.setChoices(pchoices);
		}
		if (type.equals(Type.TEST)) {
			ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
			String answer = getAnswerChoicesForMCQ();
			option = "";
			while (!checkAnswerInChoices(option, answer)) {
				System.out.println(SurveyTestConstants.MCQ_MULTI_ANSWER + answer);
				option = scan.nextLine();
			}
			correctAnswer.setResponse(getCorrectAnswer(correctAnswer, option));
			test.getCorrectAnswers().add(index - 1, correctAnswer);
		}
	}

	@Override
	public void buildQuestion(Scanner scan, Type type, Test test, int index) {
		System.out.println(SurveyTestConstants.MCQ);
		buildCommonQuestion(scan, type, test, index, true);
	}

	public String getAnswerChoicesForMCQ() {
		StringBuffer sb = new StringBuffer("[");
		for (Map.Entry<String, String> s : this.choices.entrySet()) {
			sb.append(getNumFromChar(s.getKey()) + ",");
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append("]");
		return sb.toString();
	}

	public int getNumFromChar(String a) {
		for (int i = 0; i < a.length(); ++i) {
			if (a.charAt(i) >= 'A' && a.charAt(i) <= 'Z') {
				return a.charAt(i) - 'A' + 1;
			}
		}
		return 0;
	}

	public boolean checkAnswerInChoices(String option, String answer) {
		if (option.isEmpty()) {
			return false;
		}
		answer = answer.replaceAll("\\[", "");
		answer = answer.replaceAll("\\]", "");
		String[] s1 = answer.split(",");
		String[] s2 = option.split(",");
		HashSet<String> set = new HashSet<String>();
		for (int i = 0; i < s1.length; i++) {
			for (int j = 0; j < s2.length; j++) {
				if (s1[i].equals(s2[j])) {
					set.add(s1[i]);
				}
			}
		}
		if (set.isEmpty()) {
			return false;
		}
		if (set.size() == s2.length) {
			return true;
		}
		return false;
	}

	@Override
	public void displayQuestion(Type type, Test test) {
		System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
		for (Map.Entry<String, String> s : this.choices.entrySet()) {
			System.out.print(s.getKey() + ")" + s.getValue() + "\t");
		}
		System.out.println();
		if (type.equals(Type.TEST)) {
			List<String> ans = test.getCorrectAnswers().get(this.getQuestionNumber() - 1).getResponse();
			System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS);
			StringBuffer sb = new StringBuffer();
			for (String a : ans) {
				sb.append(a + ") " + getChoices().get(a) + ", ");
			}
			sb.deleteCharAt(sb.length() - 1);
			sb.deleteCharAt(sb.length() - 1);
			System.out.println(sb.toString());
		}
		System.out.println();
	}
}
