package drexel.edu.se310.domain;

import java.util.List;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public abstract class Question {

	private String questionPrompt;
	private ResponseCorrectAnswer userAnswer;
	private int questionNumber = 0;

	public Question() {

	}

	public Question(String questionPrompt) {
		super();
		this.questionPrompt = questionPrompt;
	}

	public ResponseCorrectAnswer getUserAnswer() {
		return this.userAnswer;
	}

	public void setUserAnswer(ResponseCorrectAnswer userAnswer) {
		this.userAnswer = userAnswer;
	}

	public String getQuestionPrompt() {
		return this.questionPrompt;
	}

	public int getQuestionNumber() {
		return this.questionNumber;
	}

	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}

	public void setQuestionPrompt(String questionPrompt) {
		this.questionPrompt = questionPrompt;
	}

	public String getCharForNumber(int i) {
		return i > 0 && i < 27 ? String.valueOf((char) (i + 64)) : null;
	}

	public List<String> getCorrectAnswer(ResponseCorrectAnswer correctAnswer, String option) {
		List<String> resp = correctAnswer.getResponse();
		for (String o : option.split(",")) {
			resp.add(getCharForNumber(Integer.parseInt(o)));
		}
		return resp;
	}

	public boolean isNumeric(final String str) {
		if (str == null || str.length() == 0) {
			return false;
		}
		for (char c : str.toCharArray()) {
			if (!Character.isDigit(c)) {
				return false;
			}
		}
		return true;
	}

	protected boolean notMoreThanMax(String option) {
		if (option.isEmpty())
			return true;
		int numChoices = Integer.parseInt(option);
		if (numChoices > SurveyTestConstants.MAX_NUM_CHOICES || numChoices <= 0)
			return true;
		return false;
	}

	public abstract void buildQuestion(Scanner scan, Type type, Test test, int index);

	public abstract void displayQuestion(Type type, Test test);
}
