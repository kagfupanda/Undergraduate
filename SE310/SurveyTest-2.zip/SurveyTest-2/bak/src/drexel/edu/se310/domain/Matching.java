package drexel.edu.se310.domain;

import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class Matching extends Question {

	MatchChoice matchChoice = new MatchChoice();

	public Matching() {
		super();
	}

	public Matching(String questionPrompt) {
		super(questionPrompt);
	}

	public MatchChoice getMatchChoice() {
		return this.matchChoice;
	}

	public void setMatchChoice(MatchChoice matchChoice) {
		this.matchChoice = matchChoice;
	}

	@Override
	public void buildQuestion(Scanner scan, Type type, Test test, int index) {
		System.out.println("Enter the question:");
		String option = scan.nextLine();
		this.setQuestionPrompt(option.concat("?"));
		this.setQuestionNumber(index);
		option = "";
		while (!isNumeric(option) || notMoreThanMax(option)) {
			System.out.println(SurveyTestConstants.MCQ_CHOICES);
			System.out.println("(max choices allowed is " + SurveyTestConstants.MAX_NUM_CHOICES + ")");
			option = scan.nextLine();
		}
		int numChoices = Integer.parseInt(option);
		for (int i = 1; i <= numChoices; i++) {
			System.out.println("Column A: Enter choice #" + i);
			option = scan.nextLine();
			this.matchChoice.getColumnA().put(i - 1, option);
			System.out.println("Column B: Enter choice #" + i);
			option = scan.nextLine();
			this.matchChoice.getColumnB().put(i - 1, option);
		}

		if (type.equals(Type.TEST)) {
			for (int i = 1; i <= numChoices; i++) {
				String[] parsedOption = null;
				while (parsedOption == null || parsedOption.length != 2 || !isNumeric(parsedOption[0])
				    || !isNumeric(parsedOption[1]) || (isNumeric(parsedOption[0]) && Integer.parseInt(parsedOption[0]) != i)
				    || columnBIsMore(numChoices, parsedOption[1])) {
					System.out.println("Enter space separated correct choice for question #" + i + " [Ex: " + i + " 2]:");
					option = scan.nextLine();
					parsedOption = option.split(" ");
				}
				test.getMatchAnswers().put(Integer.parseInt(parsedOption[0]), parsedOption[1]);
			}
		}
	}

	private boolean columnBIsMore(int numChoices, String str) {
		if (isNumeric(str)) {
			int k = Integer.parseInt(str);
			if (k > numChoices || k <= 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void displayQuestion(Type type, Test test) {
		System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < this.matchChoice.getColumnA().size(); i++) {
			sb.append(i + 1 + ")" + this.matchChoice.getColumnA().get(i));
			sb.append("\t");
			sb.append(i + 1 + ")" + this.matchChoice.getColumnB().get(i));
			System.out.println(sb.toString());
			sb.delete(0, sb.length());
		}
		System.out.println();
		if (type.equals(Type.TEST)) {
			System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS);
			test.getMatchAnswers().forEach((key, value) -> System.out.println(key + " " + value));
		}
		System.out.println();
	}
}
