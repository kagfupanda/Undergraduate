package drexel.edu.se310.interfaces;

import java.util.Scanner;

public interface TestActions {

  void handleTestCreate(int index, Object rc);

  void handleTestDisplay(int index);

  void handleTestModify(int index, Scanner scan);

  void handleGrading();

  Object getMyAnswers(int index);
}
