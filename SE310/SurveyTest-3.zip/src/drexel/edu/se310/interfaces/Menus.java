package drexel.edu.se310.interfaces;

import java.beans.XMLEncoder;
import java.io.File;

import drexel.edu.se310.constants.Type;

public interface Menus {

  void Menu2(Type type);

  void createSurveyTest(Type type);

  void displaySurveyTest(Type type, File file);

  void loadSurveyTest(Type type);

  XMLEncoder saveSurveyTest(Type type, String filename);

  void modifySurveyTest(Type type);
}
