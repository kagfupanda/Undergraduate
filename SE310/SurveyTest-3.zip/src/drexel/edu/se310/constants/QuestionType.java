package drexel.edu.se310.constants;

public enum QuestionType {
  MCQ, TORF, EMOJI, ESSAY, SHORT_ANSWER, MATCHING;
}
