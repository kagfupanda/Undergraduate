package drexel.edu.se310.domain;

import java.beans.XMLEncoder;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class Test extends Survey {

  private static final long serialVersionUID = 8537526687199859878L;
  private static final String TEST_PATH = "./data/tests/";
  private Map<Integer, ResponseCorrectAnswer> correctAnswers = new HashMap<>();
  private Map<Integer, HashMap<Integer, String>> matchAnswers = new HashMap<>();

  public Test() {
    super();
  }

  public Map<Integer, ResponseCorrectAnswer> getCorrectAnswers() {
    return this.correctAnswers;
  }

  public void setCorrectAnswers(Map<Integer, ResponseCorrectAnswer> correctAnswers) {
    this.correctAnswers = correctAnswers;
  }

  public Map<Integer, HashMap<Integer, String>> getMatchAnswers() {
    return this.matchAnswers;
  }

  public void setMatchAnswers(Map<Integer, HashMap<Integer, String>> matchAnswers) {
    this.matchAnswers = matchAnswers;
  }

  @Override
  public File[] loadNDisplay(Type type) {
    String path = TEST_PATH;
    return commonLoadNDisplay(path);
  }

  @Override
  public XMLEncoder saveSurveyTest(Type type, String filename) {
    return (commonSave(type, filename, TEST_PATH));
  }

  @Override
  public void Menu2(Type type) {
    SurveyTestUtil.printBorder();
    System.out.println("Menu 2");
    SurveyTestUtil.printBorder();
    System.out.println("1) Create a new " + type);
    System.out.println("2) Display a " + type);
    System.out.println("3) Load a " + type);
    System.out.println("4) Save a " + type);
    System.out.println("5) Modify an Existing " + type);
    System.out.println("6) Take a " + type);
    System.out.println("7) Tabulate a " + type);
    System.out.println("8) Grade a " + type);
    System.out.println("9) Go back to Menu 1 ");
    System.out.println("Q) Quit");
    SurveyTestUtil.printBorder();
  }

  @Override
  public void handleTestCreate(int index, Object rc) {
    if (rc instanceof ResponseCorrectAnswer) {
      this.getCorrectAnswers().put(index, (ResponseCorrectAnswer) rc);
    } else {
      HashMap<Integer, String> pMatchAnswers = (HashMap<Integer, String>) rc;
      HashMap<Integer, String> matchAnswer = new HashMap<>();
      for (@SuppressWarnings("rawtypes")
      Map.Entry me : pMatchAnswers.entrySet()) {
        matchAnswer.put((Integer) me.getKey(), (String) me.getValue());
      }
      this.matchAnswers.put(index, matchAnswer);
    }
  }

  @Override
  public void handleTestDisplay(int index) {
    List<String> ans = null;
    Question q = this.getQuestions().get(index - 1);
    if (q.getClass() != Matching.class) {
      ans = this.getCorrectAnswers().get(index).getResponse();
      if (ans == null) {
        return;
      }
    }
    if (q.getClass() == MultipleChoice.class || q.getClass() == Emoji.class) {
      MultipleChoice newQ = null;
      newQ = (MultipleChoice) this.getQuestions().get(index - 1);
      System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS);
      StringBuffer sb = new StringBuffer();
      for (String a : ans) {
        sb.append(a + ") " + newQ.getChoices().get(a) + ", ");
      }
      sb.deleteCharAt(sb.length() - 1);
      sb.deleteCharAt(sb.length() - 1);
      System.out.println(sb.toString());
    } else if (q.getClass() == TrueFalse.class || q.getClass() == Essay.class || q.getClass() == ShortAnswer.class) {
      System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS + ans);
    } else if (q.getClass() == Matching.class) {
      System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS);
      HashMap<Integer, String> m = this.getMatchAnswers().get(index);
      m.forEach((key, value) -> System.out.println(key + " " + value));
    }
  }

  @Override
  public void handleTestModify(int index, Scanner scan) {
    Question q = this.getQuestions().get(index - 1);
    System.out.println("Do you wish to modify the correct answer?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("What choice do you wish to make the new correct answer?");
      ResponseCorrectAnswer rc = q.getCorrectAnswers(scan);
      if (rc instanceof ResponseCorrectAnswer) {
        this.getCorrectAnswers().put(index, rc);
      } else {
        HashMap<Integer, String> mr = q.getCorrectMatchingAnswers(scan);
        HashMap<Integer, String> matchAnswer = new HashMap<>();
        for (@SuppressWarnings("rawtypes")
        Map.Entry me : mr.entrySet()) {
          matchAnswer.put((Integer) me.getKey(), (String) me.getValue());
        }
        this.matchAnswers.put(index, matchAnswer);
      }
    }
  }

  @Override
  public List<File> loadAnswers() {
    File[] answerFileList = null;
    List<File> fileList = new ArrayList<>();

    File dir = new File(TEST_PATH);
    if (!dir.exists())
      System.out.println("Directory doesn't exist: " + dir.getName());

    answerFileList = dir.listFiles();
    for (File element : answerFileList) {
      if (element.isFile()) {
        if (element.getName().endsWith(".answers")) {
          fileList.add(element);
        }
      }
    }
    return fileList;
  }

  @Override
  public void handleGrading() {
    boolean flag = false;
    int essayQuestion = 0;
    int score = 0;
    if (this.getQuestions().size() <= 0) {
      System.out.println("No Test available to grade yet!!!");
      System.out.println("Please take a test to grade.");
      return;
    }
    System.out.println("Grading your test...hold on!!!");
    for (Question q : this.getQuestions()) {
      int qNum = q.getQuestionNumber();
      if (q.getClass() != Matching.class) {
        if (q.getClass() == Essay.class) {
          essayQuestion++;
          System.out.println("Skipping Essay question, can not be graded");
          continue;
        }
        List<String> ua = q.getUserAnswer().getResponse();
        List<String> rc = this.getCorrectAnswers().get(qNum).getResponse();
        Collections.sort(ua);
        Collections.sort(rc);
        if (q instanceof TrueFalse) {
          String s = ua.get(0).toUpperCase();
          ua.clear();
          ua.add(((TrueFalse) q).getChoices().get(s));
        }
        if (ua.equals(rc)) {
          flag = true;
        }
      } else {
        HashMap<Integer, String> ma = this.getMatchAnswers().get(qNum);
        HashMap<Integer, String> ua = q.getUserMatchChoiceAnswer();
        if (ma.equals(ua)) {
          flag = true;
          score++;
          System.out.println("Correct answer for matching......");
        }
      }
      if (flag) {
        score++;
        System.out.println("Correct answer for " + qNum);
      }
      // reset flag
      flag = false;
    }
    score = score * 10;
    System.out.println("Your score for this test: " + score + "/" + (this.getQuestions().size() - essayQuestion) * 10);
  }

  @Override
  public Object getMyAnswers(int index) {
    if (this.getQuestions().get(index).getClass() != Matching.class) {
      return this.getCorrectAnswers().get(index);
    } else {
      return this.getMatchAnswers().get(index + 1);
    }
  }
}
