package drexel.edu.se310.domain;

import java.util.HashMap;
import java.util.Map;

public class MatchChoice {

  private Map<Integer, String> columnA = new HashMap<>();
  private Map<Integer, String> columnB = new HashMap<>();

  public MatchChoice() {
    super();
  }

  public Map<Integer, String> getColumnA() {
    return this.columnA;
  }

  public void setColumnA(Map<Integer, String> columnA) {
    this.columnA = columnA;
  }

  public Map<Integer, String> getColumnB() {
    return this.columnB;
  }

  public void setColumnB(Map<Integer, String> columnB) {
    this.columnB = columnB;
  }

}
