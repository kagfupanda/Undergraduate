package drexel.edu.se310.domain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class Essay extends Question {

  public Essay() {
    super();
  }

  public Essay(String questionPrompt) {
    super(questionPrompt);
  }

  @Override
  public ResponseCorrectAnswer buildQuestion(Scanner scan, Type type, int index) {
    System.out.println(SurveyTestConstants.ESSAY);
    this.setQuestionType(type);
    String option = scan.nextLine();
    this.setQuestionPrompt(option.concat("?"));
    this.setQuestionNumber(index);
    return (getCorrectAnswers(scan));
  }

  @Override
  public void displayQuestion(Type type) {
    System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
  }

  @Override
  public void modifyQuestion(Scanner scan) {
    System.out.println("Do you wish to modify the essay prompt?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("Current essay prompt: " + this.getQuestionPrompt());
      System.out.println("Enter a new essay prompt:");
      String newPrompt = scan.nextLine();
      newPrompt = newPrompt.trim();
      this.setQuestionPrompt(newPrompt);
    }
  }

  @Override
  public HashMap<Integer, String> getCorrectMatchingAnswers(Scanner scan) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public ResponseCorrectAnswer getCorrectAnswers(Scanner scan) {
    if (this.getQuestionType().equals(Type.SURVEY)) {
      return null;
    }

    System.out.println(SurveyTestConstants.CORRECT_CHOICE);
    ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
    List<String> resp = correctAnswer.getResponse();

    System.out.println("Enter mulitple correct choice(s) in each line.");
    System.out.println(
        "when you are done entering multiple correct choice(s),\nHit return/enter on a new line to end entering choice(s)");
    String line = scan.nextLine();
    while (!line.equals("")) {
      resp.add(line);
      line = scan.nextLine();
    }
    correctAnswer.setResponse(resp);
    return correctAnswer;
  }

  public ResponseCorrectAnswer getUserAnswers(Scanner scan) {
    System.out.println(SurveyTestConstants.CORRECT_CHOICE);
    ResponseCorrectAnswer userAnswer = new ResponseCorrectAnswer();
    List<String> resp = userAnswer.getResponse();

    System.out.println("Enter mulitple correct choice(s) in each line.");
    System.out.println(
        "when you are done entering multiple correct choice(s),\nHit return/enter on a new line to end entering choice(s)");
    String line = scan.nextLine();
    while (!line.equals("")) {
      resp.add(line);
      line = scan.nextLine();
    }
    userAnswer.setResponse(resp);
    return userAnswer;
  }

  @Override
  public void answerQuestion(Object rc, Scanner scan) {
    ResponseCorrectAnswer userAnswer = new ResponseCorrectAnswer();
    userAnswer = getUserAnswers(scan);
    this.setUserAnswer(userAnswer);
  }

  @Override
  public void printTabulation(String i, int index, List<Map<String, Integer>> lm) {
    System.out.println(i);
  }

  @Override
  public void buildQuestionTabulation(List<Map<String, Integer>> lm, Map<String, Integer> tfCount,
      List<Map<Integer, String>> ml, int lmIndex) {
    List<String> ans = this.getUserAnswer().getResponse();
    int index = 0;
    for (String a : ans) {
      tfCount.put(a, index++);
    }
    lm.add(tfCount);
  }

}
