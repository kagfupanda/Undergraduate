package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;
import drexel.edu.se310.util.SurveyTestUtil;

public class MultipleChoice extends Question {

  private Map<String, String> choices = new HashMap<>();

  public MultipleChoice() {
    super();
  }

  public MultipleChoice(String questionPrompt) {
    super(questionPrompt);
  }

  public Map<String, String> getChoices() {
    return this.choices;
  }

  public void setChoices(Map<String, String> choices) {
    this.choices = choices;
  }

  public ResponseCorrectAnswer buildCommonQuestion(Scanner scan, Type type, int index, boolean askMCQ) {
    int numChoices = 0;
    String option = scan.nextLine();
    this.setQuestionPrompt(option.concat("?"));
    this.setQuestionNumber(index);
    option = ""; // reset
    if (askMCQ) {
      while (!isNumeric(option) || notMoreThanMax(option)) {
        System.out.println(SurveyTestConstants.MCQ_CHOICES);
        option = scan.nextLine();
      }
      Map<String, String> pchoices = new HashMap<>();
      numChoices = Integer.parseInt(option);
      for (int i = 1; i <= numChoices; i++) {
        System.out.println("Enter choice #" + i);
        option = scan.nextLine();
        pchoices.put(getCharForNumber(i), option);
      }
      this.setChoices(pchoices);
    }
    return (getCorrectAnswers(scan));
  }

  @Override
  public ResponseCorrectAnswer getCorrectAnswers(Scanner scan) {
    ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
    String answer = getAnswerChoicesForMCQ();
    if (this.getQuestionType().equals(Type.SURVEY)) {
      return null;
    }
    String option = "";
    while (!checkAnswerInChoices(option, answer)) {
      System.out.println(SurveyTestConstants.MCQ_MULTI_ANSWER + answer);
      option = scan.nextLine();
    }
    correctAnswer.setResponse(getCorrectAnswer(correctAnswer, option));
    return correctAnswer;
  }

  @Override
  public ResponseCorrectAnswer buildQuestion(Scanner scan, Type type, int index) {
    System.out.println(SurveyTestConstants.MCQ);
    this.setQuestionType(type);
    return (buildCommonQuestion(scan, type, index, true));
  }

  public String getAnswerChoicesForMCQ() {
    StringBuffer sb = new StringBuffer("[");
    for (Map.Entry<String, String> s : this.choices.entrySet()) {
      sb.append(s.getKey() + ",");
    }
    sb.deleteCharAt(sb.length() - 1);
    sb.append("]");
    return sb.toString();
  }

  public int getNumFromChar(String a) {
    for (int i = 0; i < a.length(); ++i) {
      if (a.charAt(i) >= 'A' && a.charAt(i) <= 'Z') {
        return a.charAt(i) - 'A' + 1;
      }
    }
    return 0;
  }

  public boolean checkAnswerInChoices(String option, String answer) {
    if (option.isEmpty()) {
      return false;
    }
    answer = answer.replaceAll("\\[", "");
    answer = answer.replaceAll("\\]", "");
    option = option.replaceAll("\\s", "");
    String[] s1 = answer.split(",");
    String[] s2 = option.split(",");
    HashSet<String> set = new HashSet<>();
    for (String element : s1) {
      for (String element2 : s2) {
        if (element.equalsIgnoreCase(element2)) {
          set.add(element);
        }
      }
    }
    if (set.isEmpty()) {
      return false;
    }
    if (set.size() == s2.length) {
      return true;
    }
    return false;
  }

  @Override
  public void displayQuestion(Type type) {
    System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
    for (Map.Entry<String, String> s : this.choices.entrySet()) {
      System.out.print(s.getKey() + ")" + s.getValue() + "\t");
    }
    System.out.println();
  }

  @Override
  public void modifyQuestion(Scanner scan) {
    System.out.println("Do you wish to modify the prompt?");
    boolean option = SurveyTestUtil.getYesNoAnswer();
    if (option) {
      System.out.println("Current prompt is: " + this.getQuestionPrompt());
      System.out.println("Enter a new prompt:");
      String newPrompt = scan.nextLine();
      newPrompt = newPrompt.trim();
      this.setQuestionPrompt(newPrompt);
    }
    System.out.println("Do you wish to modify choices?");
    if (SurveyTestUtil.getYesNoAnswer()) {
      System.out.println("Which choice would you like to modify?");
      for (Map.Entry<String, String> s : this.choices.entrySet()) {
        System.out.print(s.getKey() + ")" + s.getValue() + "\t");
      }
      System.out.println("\nEnter choice number: ");
      String ans = SurveyTestUtil.getMenuStringOption(true, this.choices.size());
      System.out.println("Enter new value: ");
      String newValue = scan.nextLine();
      newValue = newValue.trim();
      this.getChoices().put(ans.toUpperCase(), newValue);
    }
  }

  @Override
  public HashMap<Integer, String> getCorrectMatchingAnswers(Scanner scan) {
    return null;
  }

  @Override
  public void answerQuestion(Object rc, Scanner scan) {
    if (rc != null) {
      System.out.println("\nPlease give " + ((ResponseCorrectAnswer) rc).getResponse().size() + " choice(s):");
    }
    getUserAnswers(scan);
    System.out.println();
  }

  private void getUserAnswers(Scanner scan) {

    ResponseCorrectAnswer userAnswer = new ResponseCorrectAnswer();
    String answer = getAnswerChoicesForMCQ();
    String option = "";
    while (!checkAnswerInChoices(option, answer)) {
      System.out.println(SurveyTestConstants.MCQ_MULTI_ANSWER + answer);
      option = scan.nextLine();
    }
    String[] ansList = option.split(",");
    for (int i = 0; i < ansList.length; i++) {
      ansList[i] = ansList[i].replaceAll("\\s", "").toUpperCase();
    }
    List<String> al = new ArrayList<>();
    al.addAll(Arrays.asList(ansList));
    userAnswer.setResponse(al);
    this.setUserAnswer(userAnswer);
  }

  @Override
  public void printTabulation(String i, int index, List<Map<String, Integer>> lm) {
    System.out.println(i + ": " + lm.get(index).get(i));
  }

  @Override
  public void buildQuestionTabulation(List<Map<String, Integer>> lm, Map<String, Integer> tfCount,
      List<Map<Integer, String>> ml, int lmIndex) {
    int qNum = this.getQuestionNumber();
    if (lm.size() < qNum) {
      for (String ch : this.getChoices().keySet()) {
        tfCount.put(ch, 0);
      }
    }
    int ansCount = 0;
    for (String k : this.getChoices().keySet()) {
      List<String> ans = this.getUserAnswer().getResponse();
      for (String a : ans) {
        if (a.equalsIgnoreCase(k)) {
          ansCount++;
        }
      }
      if (ansCount > 0) {
        for (int i = 1; i <= ansCount; i++)
          SurveyTestUtil.incrementValue(tfCount, k);
      }
      ansCount = 0; // reset
    }
    Map<String, Integer> tempMap = null;
    if (lm.size() > lmIndex)
      tempMap = lm.get(lmIndex);
    if (tempMap == null) {
      lm.add(tfCount);
    } else {
      lm.set(lmIndex, tfCount);
    }
  }

}
