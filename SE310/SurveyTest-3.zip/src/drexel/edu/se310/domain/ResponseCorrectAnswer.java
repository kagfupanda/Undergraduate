package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.List;

public class ResponseCorrectAnswer {

  private List<String> response = new ArrayList<>();

  public ResponseCorrectAnswer() {
  }

  public List<String> getResponse() {
    return this.response;
  }

  public void setResponse(List<String> response) {
    this.response = response;
  }

}
