package drexel.edu.se310.domain;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import drexel.edu.se310.constants.Type;
import drexel.edu.se310.interfaces.Menus;
import drexel.edu.se310.interfaces.TestActions;
import drexel.edu.se310.util.SurveyTestUtil;

public class Survey implements Menus, TestActions, Serializable {

  private static final long serialVersionUID = 3042630321761973137L;
  private static final String SURVEY_PATH = "./data/surveys/";
  private String name;
  private List<Question> questions = new ArrayList<>();

  public Survey() {
    super();
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<Question> getQuestions() {
    return this.questions;
  }

  public void setQuestions(List<Question> questions) {
    this.questions = questions;
  }

  @Override
  public void Menu2(Type type) {
    SurveyTestUtil.printBorder();
    System.out.println("Menu 2");
    SurveyTestUtil.printBorder();
    System.out.println("1) Create a new " + type);
    System.out.println("2) Display a " + type);
    System.out.println("3) Load a " + type);
    System.out.println("4) Save a " + type);
    System.out.println("5) Modify an Existing " + type);
    System.out.println("6) Take a " + type);
    System.out.println("7) Tabulate a " + type);
    System.out.println("8) Go back to Menu 1 ");
    System.out.println("Q) Quit");
    SurveyTestUtil.printBorder();
  }

  public File[] loadNDisplay(Type type) {
    String path = SURVEY_PATH;
    return commonLoadNDisplay(path);
  }

  protected File[] commonLoadNDisplay(String path) {
    File[] fileList = null;

    FilenameFilter filter = (dir, name) -> {
      String lowercaseName = name.toLowerCase();
      if (!lowercaseName.endsWith(".answers")) {
        return true;
      } else {
        return false;
      }
    };
    String[] files = new File(path).list(filter);
    int count = 1;
    SurveyTestUtil.printBorder();

    if (files != null && files.length > 0) {
      System.out.println("Please choose a file to load:");
      int i = 0;
      fileList = new File[files.length];
      for (String s : files) {
        fileList[i++] = new File(path + s);
        System.out.println(count++ + ") " + s);
      }
      System.out.println("-------");
    } else {
      System.out.println("No files found, please choose from following menu option:");
    }
    return fileList;
  }

  @Override
  public void createSurveyTest(Type type) {
    // TODO Auto-generated method stub

  }

  @Override
  public void displaySurveyTest(Type type, File file) {
    // TODO Auto-generated method stub

  }

  @Override
  public void loadSurveyTest(Type type) {
    // TODO Auto-generated method stub

  }

  public XMLEncoder commonSave(Type type, String filename, String path) {
    XMLEncoder encoder = null;
    try {
      File file = new File(path + filename);
      if (!file.exists())
        new FileOutputStream(file).close();
      else {
        removeExistingAnswers(type, filename, path);
      }
      this.setName(file.getName());
      encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(file)));

    } catch (FileNotFoundException e) {
      System.out.println("FileNotFoundException: While Creating or Opening the File " + e);
    } catch (IOException e) {
      System.out.println("IOException: While Creating or Opening the File " + e);
    }
    return encoder;
  }

  private void removeExistingAnswers(Type type, String file, String path) {
    File[] answerFileList = null;
    boolean found = false;

    File dir = new File(path);
    if (!dir.exists())
      System.out.println("Directory doesn't exist: " + dir.getName());

    answerFileList = dir.listFiles();
    for (File element : answerFileList) {
      if (element.isFile()) {
        if (element.getName().startsWith(file) && element.getName().endsWith(".answers")) {
          element.delete();
          found = true;
        }
      }
    }
    if (found) { // print only if we are going to delete any files
      System.out.println("This " + type.toString() + " already exists!");
      System.out.println("You chose to overwrite the existing " + type.toString());
      System.out
          .println("We will delete all the associated tests taken so far\nbecause it will cause mismatch in grading");
    }
    for (File element : answerFileList) {
      if (element.isFile()) {
        if (element.getName().startsWith(file) && element.getName().endsWith(".answers")) {
          element.delete();
          System.out.println("Deleting ..." + " " + element.getName());
        }
      }
    }
    if (answerFileList.length == 0)
      System.out.println("No files");

  }

  @Override
  public XMLEncoder saveSurveyTest(Type type, String filename) {
    return (commonSave(type, filename, SURVEY_PATH));
  }

  @Override
  public void handleTestCreate(int index, Object rc) {
    // TODO Auto-generated method stub

  }

  @Override
  public void handleTestDisplay(int index) {
    // TODO Auto-generated method stub

  }

  @Override
  public void handleTestModify(int index, Scanner scan) {
    // TODO Auto-generated method stub

  }

  @Override
  public void modifySurveyTest(Type type) {
    // TODO Auto-generated method stub

  }

  @Override
  public void handleGrading() {
    System.out.println("You just took a Survey, Nothing to be graded");
  }

  @Override
  public Object getMyAnswers(int index) {
    // TODO Auto-generated method stub
    return null;
  }

  public List<File> loadAnswers() {
    // TODO Auto-generated method stub
    return null;
  }

}
