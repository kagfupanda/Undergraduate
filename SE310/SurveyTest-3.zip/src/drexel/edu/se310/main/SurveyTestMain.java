package drexel.edu.se310.main;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import drexel.edu.se310.constants.Type;
import drexel.edu.se310.domain.Emoji;
import drexel.edu.se310.domain.Essay;
import drexel.edu.se310.domain.Matching;
import drexel.edu.se310.domain.MultipleChoice;
import drexel.edu.se310.domain.Question;
import drexel.edu.se310.domain.ShortAnswer;
import drexel.edu.se310.domain.Survey;
import drexel.edu.se310.domain.Test;
import drexel.edu.se310.domain.TrueFalse;
import drexel.edu.se310.util.SurveyTestUtil;

public class SurveyTestMain {

  private Survey myType = null;
  private static Scanner scan = new Scanner(System.in);
  private int questionNum = 1;
  private String surveyPath = "./data/surveys/";
  private String testPath = "./data/tests/";

  public static void main(String[] args) {
    SurveyTestMain surveyTest = new SurveyTestMain();
    surveyTest.mainMenu();
    scan.close();
  }

  private void mainMenu() {
    SurveyTestUtil.printBorder();
    System.out.println("Main Menu 1");
    SurveyTestUtil.printBorder();
    System.out.println("1) Survey");
    System.out.println("2) Test");
    System.out.println("Q) Quit");
    SurveyTestUtil.printBorder();
    int i = Integer.parseInt(SurveyTestUtil.getMenuOption(true, 2));
    Type type = i == 1 ? Type.SURVEY : Type.TEST;
    this.questionNum = 1;
    this.myType = i == 1 ? (new Survey()) : (new Test());
    String optionStr = "";
    while (!optionStr.equalsIgnoreCase("q")) {
      this.myType.Menu2(type);
      int count = type.equals(Type.SURVEY) ? 8 : 9;
      int option = Integer.parseInt(SurveyTestUtil.getMenuOption(true, count));
      if (option == 1)
        createSurveyTest(type);
      else if (option == 2)
        displaySurveyTest(type, null);
      else if (option == 3)
        loadSurveyTest(type);
      else if (option == 4)
        saveSurveyTest(type, null);
      else if (option == 5)
        modifySurveyTest(type);
      else if (option == 6)
        takeSurveyTest(type);
      else if (option == 7)
        tabulateSurveyTest(type);
      else if (type.equals(Type.TEST) && option == 8)
        gradeSurveyTest(type);
      else if (option == count)
        mainMenu();
    }
  }

  private void tabulateSurveyTest(Type type) {
    SurveyTestUtil.printBorder();
    System.out.println("Please enter the " + type.toString() + " to Tabulate:");
    File[] files = this.myType.loadNDisplay(type);
    if (files == null) {
      return;
    }
    int count = files.length + 1;
    System.out.println(count + ") Go Back to Menu 2");
    System.out.println("Q) Quit");
    int option = Integer.parseInt(SurveyTestUtil.getMenuOption(true, count));
    if (option == count) {
      return;
    } else {
      performTabulation(type, files[option - 1]);
    }
  }

  private void performTabulation(Type type, File file) {
    List<Survey> surveyList = new ArrayList<>();
    String path = type.equals(Type.TEST) ? this.testPath : this.surveyPath;
    FilenameFilter filter = (dir, name) -> {
      String lowercaseName = name.toLowerCase();
      if (lowercaseName.startsWith(file.getName()) && lowercaseName.endsWith(".answers")) {
        return true;
      } else {
        return false;
      }
    };
    String[] answerFiles = new File(path).list(filter);
    if (answerFiles.length <= 0) {
      System.out.println("This " + type.toString() + " has not been taken yet to tabulate results!!!");
      return;
    }
    listFilesToTabulate(answerFiles);
    for (String s : answerFiles) {
      File f = new File(path + s);
      surveyList.add(readFromDiskWithReturn(type, f));
    }
    List<Map<String, Integer>> lm = new ArrayList<>();
    List<Map<Integer, String>> ml = new ArrayList<>();
    buildTabulation(surveyList, lm, ml);
    printTabulation(surveyList, lm, ml);
  }

  private void buildTabulation(List<Survey> surveyList, List<Map<String, Integer>> lm, List<Map<Integer, String>> ml) {
    Map<String, Integer> tfCount = null;
    for (Survey s : surveyList) {
      int lmIndex = 0;
      for (Question q : s.getQuestions()) {
        if (lm.size() <= lmIndex) {
          tfCount = new HashMap<>();
        } else {
          tfCount = lm.get(lmIndex);
        }
        q.buildQuestionTabulation(lm, tfCount, ml, lmIndex);
        if (!(q instanceof Matching)) {
          lmIndex++;
        }
      }
    }
  }

  private void printTabulation(List<Survey> surveyList, List<Map<String, Integer>> lm, List<Map<Integer, String>> ml) {
    SurveyTestUtil.printBorder();
    int lmIndex = 0;
    for (Question q : surveyList.get(0).getQuestions()) {
      SurveyTestUtil.printBorder();
      System.out.println("Question:");
      System.out.println(q.getQuestionNumber() + ") " + q.getQuestionPrompt());
      q.printAllTabulation(surveyList, lm, ml, lmIndex);
      if (!(q instanceof Matching)) {
        lmIndex++;
      }
    }
    SurveyTestUtil.printBorder();
  }

  private void listFilesToTabulate(String[] answerFiles) {
    SurveyTestUtil.printBorder();
    System.out.println("These answers will be tabulated:");
    SurveyTestUtil.printBorder();
    int i = 1;
    for (String s : answerFiles) {
      System.out.println(i++ + ")" + s);
    }
    SurveyTestUtil.printBorder();
  }

  private void gradeSurveyTest(Type type) {
    List<File> files = this.myType.loadAnswers();
    if (files == null) {
      return;
    }
    if (files != null && files.size() > 0) {
      System.out.println("Please choose a file to grade:");
      int count = 1;
      for (File s : files) {
        System.out.println(count++ + ") " + s.getName());
      }
      System.out.println("-------");
    } else {
      System.out.println("No Tests are taken yet, please choose from following menu option:");
      return;
    }
    int count = files.size() + 1;
    System.out.println(count + ") Go Back to Menu 2");
    System.out.println("Q) Quit");
    int option = Integer.parseInt(SurveyTestUtil.getMenuOption(true, count));
    if (option == count) {
      return;
    } else {
      this.myType = readFromDiskWithReturn(type, files.get(option - 1));
      this.myType.handleGrading();
    }

  }

  private void takeSurveyTest(Type type) {
    System.out.printf("Enter the name of the " + type.toString() + " you wish to take:\n");
    File[] files = this.myType.loadNDisplay(type);
    if (files == null) {
      return;
    }
    int count = files.length + 1;
    System.out.println(count + ") Go Back to Menu 2");
    System.out.println("Q) Quit");
    int option = Integer.parseInt(SurveyTestUtil.getMenuOption(true, count));
    if (option == count) {
      return;
    } else {
      handleTakeSurveyTest(type, files[option - 1]);
    }
  }

  private void handleTakeSurveyTest(Type type, File file) {
    readFromDisk(type, file, "Taking");
    for (Question q : this.myType.getQuestions()) {
      q.displayQuestion(type);
      q.answerQuestion(this.myType.getMyAnswers(q.getQuestionNumber() - 1), scan);
    }
    System.out.println("You are done taking the " + type.toString());
    System.out.println("Saving the " + type.toString() + " to " + file.getName());
    saveATakenSurveyTest(type, file.getName());
    this.myType.handleGrading();
    resetSurveyTest(type);
  }

  private void modifySurveyTest(Type type) {

    File[] files = this.myType.loadNDisplay(type);
    if (files == null) {
      System.out.printf("No " + type.toString() + " available to modify.");
      System.out.println("Please create a new " + type.toString() + " to modify");
      return;
    }
    System.out.printf("What " + type.toString() + " would you like to modify?\n");
    int count = files.length + 1;
    System.out.println(count + ") Go Back to Menu 2");
    System.out.println("Q) Quit");
    int option = Integer.parseInt(SurveyTestUtil.getMenuOption(true, count));
    if (option == count) {
      return;
    } else {
      displaySurveyTest(type, files[option - 1]);
    }
    System.out.println("What Question do you wish to modify?");
    int ans = Integer.parseInt(SurveyTestUtil.getMenuOption(true, this.myType.getQuestions().size()));
    this.myType.getQuestions().get(ans - 1).modifyQuestion(scan);
    this.myType.handleTestModify(ans, scan);
    saveSurveyTest(type, files[option - 1].getName());
  }

  private void displaySurveyTest(Type type, File file) {
    readFromDisk(type, file, "Displaying");
    for (Question q : this.myType.getQuestions()) {
      q.displayQuestion(type);
      this.myType.handleTestDisplay(q.getQuestionNumber());
      System.out.println();
    }
    SurveyTestUtil.printBorder();
  }

  private void readFromDisk(Type type, File file, String actionWord) {
    XMLDecoder decoder = null;

    SurveyTestUtil.printBorder();
    if (file == null && this.myType != null && this.myType.getQuestions().size() == 0) {
      System.out.println("No " + type.toString() + " questions created yet");
      System.out.println("Either load an already saved " + type.toString() + " OR create a new one.");
      return;
    }
    if (file != null) {
      try {
        decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream(file)));
      } catch (FileNotFoundException e) {
        System.out.println("ERROR: File not found");
      }
      this.myType = (Survey) decoder.readObject();
      String str = this.myType.getName() == null ? file.getName() : this.myType.getName();
      System.out.println(actionWord + " the " + type.toString() + " named " + str);
      SurveyTestUtil.printBorder();
    }
  }

  private Survey readFromDiskWithReturn(Type type, File file) {
    XMLDecoder decoder = null;

    try {
      decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream(file)));
    } catch (FileNotFoundException e) {
      System.out.println("ERROR: File not found");
    }
    Survey survey = (Survey) decoder.readObject();
    return survey;
  }

  private void loadSurveyTest(Type type) {
    File[] files = this.myType.loadNDisplay(type);
    if (files == null) {
      return;
    }
    int count = files.length + 1;
    System.out.println(count + ") Go Back to Menu 2");
    System.out.println("Q) Quit");
    int option = Integer.parseInt(SurveyTestUtil.getMenuOption(true, count));
    if (option == count) {
      return;
    } else {
      displaySurveyTest(type, files[option - 1]);
      this.questionNum = this.myType.getQuestions().size() + 1;
    }
  }

  private void resetSurveyTest(Type type) {
    this.myType = type.equals(Type.SURVEY) ? new Survey() : new Test();
  }

  private void saveATakenSurveyTest(Type type, String filename) {
    XMLEncoder encoder = null;
    Random rand = new Random();
    String path = type.equals(Type.SURVEY) ? this.surveyPath : this.testPath;
    boolean exists = true;
    while (exists) {
      int randInt = rand.nextInt(100);
      filename = filename.concat("-" + String.valueOf(randInt));
      filename = filename.concat(".answers");
      File tempFile = new File(path.concat(filename));
      exists = tempFile.exists();
    }
    encoder = this.myType.saveSurveyTest(type, filename);
    this.questionNum = 1;
    encoder.writeObject(this.myType);
    encoder.close();
  }

  private void saveSurveyTest(Type type, String fn) {
    XMLEncoder encoder = null;
    if (this.myType.getQuestions().size() <= 0 || this.myType.getQuestions().size() <= 0) {
      String str = type.equals(Type.TEST) ? Type.TEST.toString() : Type.SURVEY.toString();
      System.out.println("Nothing to save. Please create a new " + str + "\n");
      resetSurveyTest(type);
      return;
    }
    String filename = "";
    if (fn == null) {
      System.out.println("Please enter a filename to save:");
      filename = scan.nextLine();
      filename = filename.trim();
    } else {
      filename = fn;
    }
    encoder = this.myType.saveSurveyTest(type, filename);
    this.questionNum = 1;
    encoder.writeObject(this.myType);
    encoder.close();
    resetSurveyTest(type);
  }

  private void createSurveyTest(Type type) {
    String optionStr = "15";
    while (!optionStr.equalsIgnoreCase("Q")) {
      System.out.println("1) Add a new T/F question");
      System.out.println("2) Add a new multiple-choice question");
      System.out.println("3) Add a new short answer question");
      System.out.println("4) Add a new essay question");
      System.out.println("5) Add a new emoji question");
      System.out.println("6) Add a new matching question");
      System.out.println("7) Go Back to Menu 2");
      System.out.println("Q) Quit");

      optionStr = SurveyTestUtil.getMenuOption(true, 7);
      int option = Integer.parseInt(optionStr);

      Question question = null;
      if (option == 1) {
        question = new TrueFalse();
      } else if (option == 2) {
        question = new MultipleChoice();
      } else if (option == 3) {
        question = new ShortAnswer();
      } else if (option == 4) {
        question = new Essay();
      } else if (option == 5) {
        question = new Emoji();
      } else if (option == 6) {
        question = new Matching();
      } else if (option == 7) {
        return;
      }
      Object rc = question.buildQuestion(scan, type, this.questionNum++);
      this.myType.getQuestions().add(question);
      this.myType.handleTestCreate(question.getQuestionNumber(), rc);
    }
  }

}
