package drexel.edu.se310.util;

import java.util.Map;
import java.util.Scanner;

public class SurveyTestUtil {
  private static Scanner scan = new Scanner(System.in);

  public static String getMenuOption(boolean flag, int maxValue) {
    String option = "";
    if (flag) {
      while (!option.equalsIgnoreCase("q")) {
        try {
          System.out.println("Please enter a valid menu choice [1-" + maxValue + ", or Q]: ");
          option = scan.nextLine();
          option = option.trim();
          int i = Integer.parseInt(option);
          if (i > maxValue || i < 1)
            continue;
          return option;
        } catch (NumberFormatException e) {
        }
      }
    }
    if (option.equalsIgnoreCase("q")) {
      System.out.println("Quiting the program!");
      System.exit(0);
    }
    return option;
  }

  public static String getMenuOptionForTrueOrFalse() {
    String option = "";
    while (true) {
      System.out.println("Please enter a [T/F]: ");
      option = scan.nextLine();
      option = option.trim();
      if (option.equalsIgnoreCase("T") || option.equalsIgnoreCase("F")) {
        return option;
      }
    }
  }

  public static String getGenericMenuOption() {
    String option = "";
    System.out.println("Please enter an answer: ");
    option = scan.nextLine();
    option = option.trim();
    return option;
  }

  public static String getMenuStringOption(boolean flag, int maxValue) {
    String option = "";
    if (flag) {
      while (!option.equalsIgnoreCase("q")) {
        try {
          char c = (char) (65 + maxValue - 1);
          System.out.println("Please enter a valid choice [A-" + c + ", or Q]: ");
          option = scan.nextLine();
          option = option.trim();
          if (option.length() != 1) {
            continue;
          }
          int at = option.toUpperCase().charAt(0);
          if (at >= 65 && at <= c)
            return option;
        } catch (NumberFormatException e) {
        }
      }
    }
    if (option.equalsIgnoreCase("q")) {
      System.out.println("Quiting the program!");
      System.exit(0);
    }
    return option;
  }

  public static void printBorder() {
    System.out.println("===============================");
  }

  public static boolean getYesNoAnswer() {
    String option = "";
    while (true) {
      System.out.println("Please enter a valid answer [yes, no]: ");
      option = scan.nextLine();
      option = option.trim();
      if (option.equalsIgnoreCase("yes")) {
        return true;
      }
      if (option.equalsIgnoreCase("no")) {
        return false;
      }
    }
  }

  public static boolean getUserAnswer() {
    String option = "";
    while (!option.equalsIgnoreCase("q")) {
      option = scan.nextLine();
      option = option.trim();
    }
    return false;
  }

  public static void incrementValueMapOfMap(Map<Map<Integer, String>, Integer> myMap, Map<Integer, String> a) {
    Integer p = myMap.get(a);
    if (p == null) {
      myMap.put(a, 1);
    } else {
      myMap.put(a, p + 1);
    }
  }

  public static void incrementValue(Map<String, Integer> myMap, String a) {
    Integer count = myMap.get(a.toUpperCase());
    if (count == null) {
      myMap.put(a, 1);
    } else {
      myMap.put(a, count + 1);
    }
  }

  public static void incrementValueWithSameCaseForShortAnswers(Map<String, Integer> myMap, String a) {
    Integer count = myMap.get(a);
    if (count == null) {
      myMap.put(a, 1);
    } else {
      myMap.put(a, count + 1);
    }
  }
}
