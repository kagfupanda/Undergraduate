package drexel.edu.se310.constants;

public class SurveyTestConstants {
	public static final String TORF = "Enter the prompt for your True/False question:";
	public static final String SHORTANSWER = "Enter the prompt for your Short Answer question:";
	public static final String MCQ = "Enter the prompt or your multiple-choice question:";
	public static final String MCQ_CHOICES = "Enter the number of choices for your multiple-choice question.";
	public static final String ESSAY = "Enter the prompt or your Essay question:";
	public static final String EMOJI = "Enter the prompt or your Emoji question:";
	public static final String SMILES = "Smiles";
	public static final String FROWN = "Frowns";
	public static final String ANGRY = "Angry";
	public static final String SURPRISED = "Surprised";
	public static final String SAD = "Sad";
	public static final String TRUE = "T";
	public static final String FALSE = "F";
	public static final String CORRECT_CHOICE = "Enter correct choice:";
	public static final String CORRECT_CHOICE_ANS = "\nThe correct choice is ";
	public static final int MAX_NUM_CHOICES = 5;
	public static final String MCQ_MULTI_ANSWER = "Enter comma separated more than one correct choice:";

	private SurveyTestConstants() {
	}
}
