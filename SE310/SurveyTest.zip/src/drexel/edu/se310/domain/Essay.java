package drexel.edu.se310.domain;

import java.util.List;
import java.util.Scanner;

import drexel.edu.se310.constants.SurveyTestConstants;
import drexel.edu.se310.constants.Type;

public class Essay extends Question {

	public Essay() {
		super();
	}

	public Essay(String questionPrompt) {
		super(questionPrompt);
	}

	@Override
	public void buildQuestion(Scanner scan, Type type, Test test, int index) {
		System.out.println(SurveyTestConstants.ESSAY);
		String option = scan.nextLine();
		this.setQuestionPrompt(option.concat("?"));
		this.setQuestionNumber(index);
		if (type.equals(Type.TEST)) {
			System.out.println(SurveyTestConstants.CORRECT_CHOICE);
			option = scan.nextLine();
			if (test != null) {
				ResponseCorrectAnswer correctAnswer = new ResponseCorrectAnswer();
				List<String> resp = correctAnswer.getResponse();
				resp.add(option);
				correctAnswer.setResponse(resp);
				test.getCorrectAnswers().add(index - 1, correctAnswer);
			}
		}
	}

	@Override
	public void displayQuestion(Type type, Test test) {
		System.out.println(this.getQuestionNumber() + ") " + this.getQuestionPrompt());
		if (type.equals(Type.TEST)) {
			System.out.println(SurveyTestConstants.CORRECT_CHOICE_ANS
			    + test.getCorrectAnswers().get(this.getQuestionNumber() - 1).getResponse());
		}
		System.out.println();
	}

}
