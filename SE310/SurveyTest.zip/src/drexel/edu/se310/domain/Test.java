package drexel.edu.se310.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Test extends Survey {

  private List<ResponseCorrectAnswer> correctAnswers = new ArrayList<>();
  private HashMap<Integer, String> matchAnswers = new HashMap<>();

  public List<ResponseCorrectAnswer> getCorrectAnswers() {
    return this.correctAnswers;
  }

  public void setCorrectAnswers(List<ResponseCorrectAnswer> correctAnswers) {
    this.correctAnswers = correctAnswers;
  }

  public HashMap<Integer, String> getMatchAnswers() {
    return this.matchAnswers;
  }

  public void setMatchAnswers(HashMap<Integer, String> matchAnswers) {
    this.matchAnswers = matchAnswers;
  }

}
