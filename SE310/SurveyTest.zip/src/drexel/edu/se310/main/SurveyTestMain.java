package drexel.edu.se310.main;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import drexel.edu.se310.constants.Type;
import drexel.edu.se310.domain.Emoji;
import drexel.edu.se310.domain.Essay;
import drexel.edu.se310.domain.Matching;
import drexel.edu.se310.domain.MultipleChoice;
import drexel.edu.se310.domain.Question;
import drexel.edu.se310.domain.ShortAnswer;
import drexel.edu.se310.domain.Survey;
import drexel.edu.se310.domain.Test;
import drexel.edu.se310.domain.TrueFalse;

public class SurveyTestMain {
	Scanner scan = new Scanner(System.in);
	Survey survey = new Survey();
	Test test = new Test();
	int qNumSurvey = 1, qNumTest = 1;
	private static final String TEST_PATH = "./data/tests/";
	private static final String SURVEY_PATH = "./data/surveys/";

	public static void main(String[] args) {
		SurveyTestMain surveyTest = new SurveyTestMain();
		surveyTest.mainMenu();
		surveyTest.scannerClose();
	}

	public void scannerClose() {
		this.scan.close();
	}

	private void mainMenu() {
		printBorder();
		System.out.println("Main Menu 1");
		printBorder();
		System.out.println("1) Survey");
		System.out.println("2) Test");
		System.out.println("Q) Quit");
		printBorder();
		int i = Integer.parseInt(getMenuOption(true, 2));
		if (i == 1) {
			Menu2(Type.SURVEY);
		}
		if (i == 2) {
			Menu2(Type.TEST);
		}
	}

	private void Menu2(Type type) {
		String optionStr = "";
		while (!optionStr.equalsIgnoreCase("Q")) {
			printBorder();
			System.out.println("Menu 2");
			printBorder();
			System.out.println("1) Create a new " + type);
			System.out.println("2) Display a " + type);
			System.out.println("3) Load a " + type);
			System.out.println("4) Save a " + type);
			System.out.println("5) Go back to Menu 1 ");
			System.out.println("Q) Quit");
			printBorder();
			int option = Integer.parseInt(getMenuOption(true, 5));
			if (option == 1)
				createSurveyTest(type);
			else if (option == 2)
				displaySurveyTest(type, null);
			else if (option == 3)
				loadSurveyTest(type);
			else if (option == 4)
				saveSurveyTest(type);
			else if (option == 5)
				mainMenu();
		}
	}

	public void displaySurveyTest(Type type, File file) {
		XMLDecoder decoder = null;

		if (file != null) {
			try {
				decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream(file)));
			} catch (FileNotFoundException e) {
				System.out.println("ERROR: File not found");
			}
		}
		if (type.equals(Type.SURVEY)) {
			if (file != null) {
				this.survey = (Survey) decoder.readObject();
				String str = this.survey.getName() == null ? file.getName() : this.survey.getName();
				printBorder();
				System.out.println("Displaying the SURVEY named " + str);
				printBorder();
			}
			for (Question q : this.survey.getQuestions()) {
				q.displayQuestion(type, this.test);
			}
			if (this.survey != null && this.survey.getQuestions().size() == 0) {
				System.out.println("No " + type.toString() + " questions created yet");
				System.out.println("Either load an already saved " + type.toString() + " OR create a new one.");
			}
		} else {
			if (file != null) {
				this.test = (Test) decoder.readObject();
				String str = this.test.getName() == null ? file.getName() : this.test.getName();
				printBorder();
				System.out.println("Displaying the TEST named " + str);
				printBorder();
			}
			for (Question q : this.test.getQuestions()) {
				q.displayQuestion(type, this.test);
			}
			if (this.test != null && this.test.getQuestions().size() == 0) {
				System.out.println("No " + type.toString() + " questions created yet");
				System.out.println("Either load an already saved " + type.toString() + " OR create a new one.");
			}
		}
	}

	public void loadSurveyTest(Type type) {
		String optionStr = "";
		String path = type.equals(Type.TEST) ? TEST_PATH : SURVEY_PATH;
		while (!optionStr.equalsIgnoreCase("Q")) {
			File[] files = new File(path).listFiles();
			int count = 1;
			printBorder();
			if (files != null && files.length > 0) {
				System.out.println("Please choose a file to load:");
				for (File f : files) {
					String file = f.getName();
					System.out.println(count++ + ") " + file);
				}
				System.out.println("-------");
			} else {
				System.out.println("No files to load, please choose from following menu option:");
			}
			System.out.println(count + ") Go Back to Menu 2");
			System.out.println("Q) Quit");
			int option = Integer.parseInt(getMenuOption(true, count));
			if (option == count) {
				Menu2(type);
			}
			displaySurveyTest(type, files[option - 1]);
		}
	}

	public void saveSurveyTest(Type type) {
		XMLEncoder encoder = null;
		if ((type.equals(Type.TEST) && this.test.getQuestions().size() > 0)
		    || (type.equals(Type.SURVEY) && this.survey.getQuestions().size() > 0)) {
			System.out.println("Please enter a filename to save:");
			String filename = this.scan.nextLine();
			filename = filename.trim();
			String path = type.equals(Type.SURVEY) ? SURVEY_PATH : TEST_PATH;
			try {
				File file = new File(path + filename);
				if (!file.exists())
					new FileOutputStream(file).close();
				if (type.equals(Type.TEST)) {
					this.test.setName(file.getName());
				} else {
					this.survey.setName(file.getName());
				}
				encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(file)));
			} catch (FileNotFoundException e) {
				System.out.println("FileNotFoundException: While Creating or Opening the File " + e);
			} catch (IOException e) {
				System.out.println("IOException: While Creating or Opening the File " + e);
			}
			this.qNumSurvey = 1;
			this.qNumTest = 1;
			encoder.writeObject(type.equals(Type.TEST) ? this.test : this.survey);
			encoder.close();
		} else {
			String str = type.equals(Type.TEST) ? Type.TEST.toString() : Type.SURVEY.toString();
			System.out.println("Nothing to save. Please create a new " + str + "\n");
		}
		// Reset the test and Survey objects as it's saved now.
		if (type.equals(Type.SURVEY)) {
			this.survey = new Survey();
		} else {
			this.test = new Test();
		}
	}

	public void createSurveyTest(Type type) {
		String optionStr = "15";

		while (!optionStr.equalsIgnoreCase("Q")) {
			System.out.println("1) Add a new T/F question");
			System.out.println("2) Add a new multiple-choice question");
			System.out.println("3) Add a new short answer question");
			System.out.println("4) Add a new essay question");
			System.out.println("5) Add a new emoji question");
			System.out.println("6) Add a new matching question");
			System.out.println("7) Go Back to Menu 2");
			System.out.println("Q) Quit");

			optionStr = getMenuOption(true, 7);
			int option = Integer.parseInt(optionStr);

			Question question = null;
			if (option == 1) {
				question = new TrueFalse();
			} else if (option == 2) {
				question = new MultipleChoice();
			} else if (option == 3) {
				question = new ShortAnswer();
			} else if (option == 4) {
				question = new Essay();
			} else if (option == 5) {
				question = new Emoji();
			} else if (option == 6) {
				question = new Matching();
			} else if (option == 7) {
				return;
			}
			if (type.equals(Type.TEST)) {
				question.buildQuestion(this.scan, type, this.test, this.qNumTest++);
				this.test.getQuestions().add(question.getQuestionNumber() - 1, question);
			}
			if (type.equals(Type.SURVEY)) {
				question.buildQuestion(this.scan, type, null, this.qNumSurvey++);
				this.survey.getQuestions().add(question.getQuestionNumber() - 1, question);
			}
		}
	}

	private String getMenuOption(boolean flag, int maxValue) {
		String option = "";
		if (flag) {
			while (!option.equalsIgnoreCase("q")) {
				try {
					System.out.println("Please enter a valid menu choice [1-" + maxValue + ", or Q]: ");
					option = this.scan.nextLine();
					option = option.trim();
					int i = Integer.parseInt(option);
					if (i > maxValue || i < 1)
						continue;
					return option;
				} catch (NumberFormatException e) {
				}
			}
		}
		if (option.equalsIgnoreCase("q")) {
			System.out.println("Quiting the program!");
			System.exit(0);
		}
		return option;
	}

	private void printBorder() {
		System.out.println("===============================");
	}
}
